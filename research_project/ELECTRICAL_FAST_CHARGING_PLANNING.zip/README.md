# Dissertation Proposal LaTeX repo

This repo contains the files for building the latex disserataion proposal. This is not an official template from the school. If you want to make changes to it, feel free to raise an issue/pull request on [Github](https://github.com/PortNLP/psu-dissertation-template/).